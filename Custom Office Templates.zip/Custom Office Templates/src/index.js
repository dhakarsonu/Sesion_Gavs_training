import './sass/main.scss';

class A{
    constructor(){

    }
}
export default new A();