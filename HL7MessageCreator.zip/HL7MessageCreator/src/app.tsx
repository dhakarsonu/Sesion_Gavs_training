import * as React from 'react';
import { hot } from "react-hot-loader/root";
import { BrowserRouter as Router, Route, Link,Switch } from "react-router-dom";
import AdmitPatient from './components/AdmitPatient';
import Surgery from './components/Surgery';
import LabMessage from './components/LabMessage';
import CancelAdmit from './components/CancelAdmit';
import CancelDischarge from  './components/CancelDischarge';
import DevicePatient from './components/DevicePatient';
import DischargePatient from './components/DischargePatient';
import TransferPatient from './components/TransferPatient';
import CancelTransfer from './components/CancelTransfer';
import MAR from './components/MAR';
import Medication from './components/Medication';

import "./sass/main.scss";

class App extends React.Component {

    constructor(props:any){
        super(props);
    }

    handleOnClickEvent = (event:any):void =>{
        var target =event.target;
        if(['LI','A'].indexOf(target.nodeName) <= 0 )
            return;
        target = target.nodeName == 'LI' ? target : target.parentElement;
        var LiEle = target.parentElement.querySelector(".active");
        if(LiEle){
            LiEle.classList.remove("active");
        }
        target.classList.add("active");
    }

    componentDidMount(){
        var path = window.location.pathname;
        path = path.split("/")[1];
        var activeLink:Element|null = document.querySelector(".main-links > li.active");
        if(activeLink){
            activeLink.classList.remove("active");
        }
        activeLink = document.getElementById(path);
        if(!activeLink){
            activeLink = document.querySelector(".admitPatient");
            if(activeLink)
                activeLink.classList.add("active");
            return;
        }
        activeLink.classList.add("active");
    }
    
    render():JSX.Element {
        return(
            <Router>
                <div>
                    <header className="main-header">
                        <a href="#">HL7 Message Gen</a>
                        <div>
                            <ul className="topnav main-links" onClick={this.handleOnClickEvent}>
                                <li className="active admitPatient" id="admitPatient">
                                    <Link to="/admitPatient">Admit Patient</Link>
                                </li>
                                <li className="cancelAdmit" id="cancelAdmit">
                                    <Link to="/cancelAdmit">Cancel Admit</Link>
                                </li>
                                <li className="transferPatient" id="transferPatient">
                                    <Link to="/transferPatient">Transfer Patient</Link>
                                </li>
                                <li className="cancleTransfer" id="cancleTransfer">
                                    <Link to="/cancleTransfer">Cancel Transfer</Link>
                                </li>
                                <li className="dischargePatient" id="dischargePatient">
                                    <Link to="/dischargePatient">Discharge Patient</Link>
                                </li>
                                <li className="cancelDischarge" id="cancelDischarge">
                                    <Link to="/cancelDischarge">Cancel Discharge</Link>
                                </li>
                                <li className="labMessage" id="labMessage">
                                    <Link to="/labMessage">Lab Message</Link>
                                </li>
                                <li className="medication" id="labMessage">
                                    <Link to="/medication">Pharmacy</Link>
                                </li>
                                <li className="surgery" id="surgery">
                                    <Link to="/surgery">Add Surgery</Link>
                                </li>
                                <li className="devicePatient" id="devicePatient">
                                    <Link to="/devicePatient">Add Device</Link>
                                </li>
                                <li className="mar" id="labMessage">
                                    <Link to="/mar">MAR</Link>
                                </li>
                            </ul>
                        </div>
                    </header>
                    <div className="main-container">
                        <Switch>
                            <Route exact path="/">
                                <AdmitPatient data={{}}/>
                            </Route>
                            <Route exact path="/admitPatient">
                                <AdmitPatient data={{}}/>
                            </Route>
                            <Route exact path="/surgery">
                                <Surgery />
                            </Route>
                            <Route exact path="/labMessage">
                                <LabMessage />
                            </Route>
                            <Route exact path="/cancelAdmit">
                                <CancelAdmit />
                            </Route>
                            <Route exact path="/dischargePatient">
                                <DischargePatient />
                            </Route>
                            <Route exact path="/cancelDischarge">
                                <CancelDischarge />
                            </Route>
                            <Route exact path="/devicePatient">
                                <DevicePatient />
                            </Route>
                            <Route exact path="/transferPatient">
                                <TransferPatient />
                            </Route>
                            <Route exact path="/cancleTransfer">
                                <CancelTransfer />
                            </Route>
                            <Route exact path="/mar">
                                <MAR />
                            </Route>
                            <Route exact path="/medication">
                                <Medication />
                            </Route>
                        </Switch>
                    </div>
                </div>
            </Router>
        )
    }
}

export default hot(App);