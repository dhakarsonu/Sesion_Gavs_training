import * as React from 'react';
import { hot } from "react-hot-loader/root";
import TextField from '@material-ui/core/TextField';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import IconButton from '@material-ui/core/IconButton';
import SvgIcon from '@material-ui/core/SvgIcon';
import ContentEditable from 'react-contenteditable';
import Checkbox from '@material-ui/core/Checkbox';
 
const data = require("../data/LabPatient.json");
let DB = require("../DB.json");

console.log(DB);

const root = {
    margin: 10+"px",
    border:"1px solid gray"
};

interface Props {}
  
interface State {
    selectedOption: String;
    mshOption:String
    pv1Option:String
    pidOption:String
    message:any,
    patient:any,
    index:any,
    allActive:boolean
}

class Lab extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props);
        this.state = { 
            selectedOption: "", 
            mshOption : "Select Other Feild",
            pv1Option : "Select Other Feild",
            pidOption : "Select Other Feild",
            patient : JSON.parse(JSON.stringify(DB.patient)),
            message : [],
            index : 0,
            allActive : true
        };
        this.inputFields = this.inputFields.bind(this);
        this.segments = this.segments.bind(this);
        this.handleMSHChange = this.handleMSHChange.bind(this);
        this.handlePV1Change = this.handlePV1Change.bind(this);
        this.handlePIDChange = this.handlePIDChange.bind(this);
        this.onChangeHandler = this.onChangeHandler.bind(this);
        this.generateMessage = this.generateMessage.bind(this);
        this.onKeyPressHandler = this.onKeyPressHandler.bind(this);
        this.onChangeDateHandler = this.onChangeDateHandler.bind(this);
    }

    changeHandler = (event:any)=>{

        var checked = event.target.checked;
        if(checked){
            this.selectAll();
            return;
        }
        this.deSelectAll();

    }

    componentWillMount(){
        var patients:any = [];
        this.state.patient.map((patient:any)=>{
            patient.ORC = data.ORC;
            var OBR:any = data.OBR;
            Object.keys(data.OBR).map((key)=>{
                var value = data.OBR[key].value;
                if(key === "ObservationDate/Time" || key === "SpecimenReceivedDate/Time" || key === "ResultsRpt/StatusChng-Date/Time" || key === "ScheduledDate/Time"){
                    value = patient.MSH["dateAndTime"].value;
                }
                if(key === "Quantity/Timing"){
                    value = "1^^^"+patient.MSH["dateAndTime"].value+"^^R~^^^^^R";
                }
                OBR[key].value = value
            });
            patient.OBR = OBR;
            patient.OBX = data.OBX;
            patients.push(patient);
        });
        this.setState({patient:patients});
    }

    bindKeyDownHandler(){
        window.addEventListener("keydown",this.onKeyPressHandler);
    }
    unBindKeyDownHandler(){
        window.removeEventListener("keydown",this.onKeyPressHandler);
    }

    onKeyPressHandler = (event:any) =>{
        if(event.keyCode == 27){
            this.hideModel();
        }
    }

    onChangeHandler = (event:any) =>{
        event.stopPropagation();
        event.preventDefault();
        let mainKey = event.target.id.split(" ")[1];
        let subKey  = event.target.id.split(" ")[0];
        var patients = JSON.parse(JSON.stringify(this.state.patient));
        patients[this.state.index][mainKey][subKey].value = event.target.value;
        this.setState({patient:patients});
    }

    onChangeDateHandler = (event:any) =>{
        console.log(event.target.value);
    }

    inputFields = (data:any,segmentKey:any,mainKey:any) =>{
        if(!data.required)
        return "";
        segmentKey = segmentKey.trim();
        switch(segmentKey){
            case "no-segment" :
                return (
                    <TextField
                        id="datetime-local"
                        label="Date & Time"
                        type="datetime-local"
                        defaultValue="2020-01-01T10:00"
                        InputLabelProps={{
                            shrink: true,
                        }}
                        onChange={this.onChangeDateHandler}
                    />
                );
            default:
                return (
                    <TextField
                        required
                        id={segmentKey+" "+mainKey}
                        key={data.value}
                        label={data.label}
                        defaultValue={data.value}
                        variant="outlined"
                        style={{margin:10+"px"}}
                        onChange={this.onChangeHandler}
                    />
                );
        }
    }

    handleMSHChange = (event:any) =>{
        this.state.patient[this.state.index].MSH[event.target.value].required = true;
        this.setState({patient:this.state.patient});
    }
    handlePV1Change = (event:any) =>{
        this.state.patient[this.state.index].PV1[event.target.value].required = true;
        this.setState({patient:this.state.patient});
    }
    handlePIDChange = (event:any) =>{
        this.state.patient[this.state.index].PID[event.target.value].required = true;
        this.setState({patient:this.state.patient});
    }

    handleORCChange = (event:any) =>{
        this.state.patient[this.state.index].ORC[event.target.value].required = true;
        this.setState({patient:this.state.patient});
    }

    handleOBCChange = (event:any) =>{
        this.state.patient[this.state.index].OBC[event.target.value].required = true;
        this.setState({patient:this.state.patient});
    }

    handleOBXChange = (event:any) =>{
        this.state.patient[this.state.index].OBX[event.target.value].required = true;
        this.setState({patient:this.state.patient});
    }

    segments = (segment:any,key:any) =>{
        if(key === "MSH" || key === "PV1" || key === "PID" || key.toLowerCase() === "isremove")
            return "";

        let value:String = "Select Other Feild";
        let onChange;
        if(key === "MSH"){
            onChange = this.handleMSHChange;
        }else if(key === "PV1"){
            onChange = this.handlePV1Change;
        }else 
        
        if(key === "ORC"){
            onChange = this.handleORCChange;
        }
        else if(key === "OBC"){
            onChange = this.handleOBCChange;
        }
        else if(key === "OBX"){
            onChange = this.handleOBXChange;
        }else{
            onChange = this.handlePIDChange;
        }
        return (
            <form style={root} noValidate>
                <header style={{border:'1px solid gray',height:40+"px",background: "rgba(35, 104, 208, 0.09)"}}>
                    <span style={{ position: 'relative', top: '10px', left: '30px',fontWeight: 600}}>{key}</span>
                    <FormControl style={{minWidth: 120, position: 'relative', left: 36+"%"}}>
                        <Select
                            labelId={key+"demo-simple-select-label"}
                            id={key+"demo-simple-select"}
                            value={value}
                            onChange={onChange}
                        >
                        {
                             Object.keys(segment).map((segmentKey:any)=>{
                                var data = segment[segmentKey];
                                 return  <MenuItem style={data.required ? {'display':"none"} : {}} value={segmentKey}>{data.label}</MenuItem>
                             }) 
                        }
                        <MenuItem value="Select Other Feild">Select Other Field</MenuItem>
                        </Select>
                    </FormControl>
                </header>
                {
                   Object.keys(segment).map((segmentKey:any)=>{
                    var data = segment[segmentKey];
                     return this.inputFields(data,segmentKey,key);
                 }) 
                }
            </form>
        )
    }

    getMonthDay = (month:string,year:string)=>{
        if(month == "01" || month == "03" || month == "05" || month == "07" || month == "08" || month == "10" || month == "12"){
            return 31;
        }else if(month == "02"){
            if(parseInt(year) % 4 === 0){
                return 29;
            }else{
                return 28;
            }
        }
        return 30;
    }

    generateMessage = (event:any) =>{
        var message:any=[];
        this.state.patient.map((dataObj:any)=>{
            if(!dataObj.isRemove){
                var msh = "MSH|";
                Object.keys(dataObj.MSH).map((key)=>{
                    if(key != "fieldSeperator"){
                        var data = dataObj.MSH[key];
                        if(key === "dateAndTime"){
                            data.value = dataObj.MSH[key].value;
                            var year = data.value.substring(0,4);
                            var month = data.value.substring(4,6);
                            var day = data.value.substring(6,8);
                            var hour = data.value.substring(8,10);
                            var min = data.value.substring(10,12);
                            var sec = data.value.substring(12,14);
                            var monthEnd = this.getMonthDay(month,year);
                            hour =  parseInt(hour);
                            month = parseInt(month);
                            year = parseInt(year);
                            hour++;
                            if(hour > 23){
                                hour = "00";
                                day++;
                                if(day > monthEnd){
                                    day = "01";
                                    month++;
                                    if(month > 12){
                                        month = "01";
                                        year++;
                                    }
                                }
                            }
                            data.value = year.toString() + month.toString() + day.toString() + hour.toString() + min + sec;
                        }

                        msh += data.value + (key != "principalLanguageOfMessage" ? "|" : "")
                    }
                });

                var pid = "PID|";
                Object.keys(dataObj.PID).map((key)=>{
                    var data = dataObj.PID[key];
                    pid += data.value + (key != "patientDeathIndicator" ? "|" : "")
                });

                var pv1 = "PV1|";
                Object.keys(dataObj.PV1).map((key)=>{
                    var data = dataObj.PV1[key];
                    pv1 += data.value + (key != "otherHealthcareProvider" ? "|" : "")
                });

                var orc = "ORC|";
                Object.keys(dataObj.ORC).map((key)=>{
                    var data = dataObj.ORC[key];
                    orc += data.value + (key != "ActionBy" ? "|" : "")
                });

                var obr = "OBR|";
                Object.keys(dataObj.OBR).map((key)=>{
                    var data = dataObj.OBR[key];
                    obr += data.value + (key != "PlannedPatientTransportComment" ? "|" : "")
                });

                var obx = "OBX|";
                Object.keys(dataObj.OBX).map((key)=>{
                    var data = dataObj.OBX[key];
                    obx += data.value + (key != "ObservationMethod" ? "|" : "")
                });

                var obj = {msh,pv1,pid,orc,obr,obx};

                message.push(obj);
            }
        });

        this.setState({message});

        event.target.nextElementSibling.classList.remove("hide");
        event.target.previousElementSibling.classList.remove("hide");

        this.bindKeyDownHandler();
    }


    hideModel = () =>{
        let overlay:Element|null = document.querySelector(".overlay");
        if(overlay)
            overlay.classList.add("hide");
        
        let messageDisplay:Element|null = document.querySelector(".message-display");
        if(messageDisplay)
            messageDisplay.classList.add("hide");
        this.setState({message:[]});

        this.unBindKeyDownHandler();
    }

    handleMessageChange = () =>{
        
    }

    allMessages = () =>{
        var messages = "";
        this.state.message.map((obj:any)=>{
            messages += "<div class='message-seperator-wrapper'><div>" + obj.msh + "</div>" + "<div>"+obj.pid+"</div>" + "<div>"+obj.pv1+"</div>"+ "<div>"+obj.orc+"</div>" + "<div>"+obj.obr+"</div>" + "<div>"+obj.obx+"</div><br></div>"
        });
        messages = messages || "No Patient Found!";
        return messages;
    }

    deSelectAll = () =>{
        var allPatient = document.querySelectorAll("section.left > ul > li");
        allPatient.forEach((patient)=>{
            patient.classList.remove("active");
        });

        this.state.patient.map((patient:any)=>{
            patient.isRemove = true;
        });

        this.setState({patient : this.state.patient,allActive:false});
    }

    selectAll = () =>{
        var allPatient = document.querySelectorAll("section.left > ul > li");
        allPatient.forEach((patient)=>{
            patient.classList.add("active");
        });

        this.state.patient.map((patient:any)=>{
            patient.isRemove = false;
        });

        this.setState({patient : this.state.patient,allActive:true});
    }

    selectPatient = (event:any) =>{
        event.stopPropagation();
        event.preventDefault();
        var target = event.target;
        target = target.nodeName === "LI" ? target : target.closest("li");
        var index = parseInt(target.id);
        var patients = JSON.parse(JSON.stringify(this.state.patient));
        if(target.classList.contains('active')){
            target.classList.remove("active");
            var patient = patients[index];
            if(patient && !patient.isRemove){
                patient.isRemove = true;
                patients[index] = patient;
            }
        }else{
            target.classList.add("active");
            var patient = patients[index];
            patient.isRemove = false;
            patients[index] = patient;
        }

        this.setState({patient : patients,index});
    }

    render():JSX.Element {
        var counter = 0;
        var buttonVisibility = this.state.patient.length > 0 ? '' : 'none';
        var emptyViewVisibility = buttonVisibility === "" ? 'none' : 'block';

        if(this.state.patient[this.state.index]){
            return(
                <div className="admit-patient-wrapper">
                    <section className="left">
                        <div style={{'display':buttonVisibility}}>
                            <Checkbox
                                checked={this.state.allActive}
                                color="primary"
                                onChange={this.changeHandler}
                                inputProps={{ 'aria-label': 'primary checkbox' }}
                            />
                            <span>Patients</span>
                        </div>
                        <div style={{'display':emptyViewVisibility}}>
                            <span>No Patient Found</span>
                            <a href="/admitPatient">Admit Patient</a>
                        </div>
                        <ul>
                            {
                                this.state.patient.map((data:any)=>{
                                    return <li key={counter} className="active" onClick={this.selectPatient} id={(counter++).toString()}>
                                        <div>
                                            <Checkbox
                                                checked={!data.isRemove}
                                                color="primary"
                                                inputProps={{ 'aria-label': 'primary checkbox' }}
                                            /> 
                                        </div>
                                        <div>
                                            <span>{data.PID.internalPatientId.value}</span>
                                            <span>{data.PID.patientName.value.replace("^"," ")}</span>
                                        </div>
                                    </li>
                                })
                            }
                        </ul>
                    </section>
                    <section className="right">
                        {
                            Object.keys(this.state.patient[this.state.index]).map((key:any)=>{
                                var segment = this.state.patient[this.state.index][key];
                                return this.segments(segment,key);
                            })
                        }
                        <footer style={{textAlign:"center"}}>
                            <div className="overlay hide" onClick={this.hideModel}></div>
                            <button onClick={this.generateMessage}>Generate</button>
                            <div className="message-display hide">
                                <IconButton aria-label="delete" style={{'position' : 'relative', float: 'right',bottom: '20px',left: '20px'}} onClick={this.hideModel}>
                                <SvgIcon>
                                    <path d="M14.59 8L12 10.59 9.41 8 8 9.41 10.59 12 8 14.59 9.41 16 12 13.41 14.59 16 16 14.59 13.41 12 16 9.41 14.59 8zM12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" />
                                </SvgIcon>
                                </IconButton>
                                <div className="message-wrapper">
                                    <ContentEditable
                                        html={this.allMessages()} // innerHTML of the editable div
                                        style={{borderBottom:'10px',padding:'5px',borderRadius:'5px',border:'1px ridge #80808029'}}
                                        disabled={false}       // use true to disable editing
                                        onChange={this.handleMessageChange} // handle innerHTML change
                                        tagName='p'
                                    />
                                </div>
                            </div>
                        </footer>
                    </section>
                </div>
            ) 
        }

        return(
            <div className="admit-patient-wrapper">
                <section className="left">
                    <div style={{'display':emptyViewVisibility}}>
                        <span>No Patient Found</span>
                        <a href="/admitPatient">Admit Patient</a>
                    </div>
                    <ul>
                        {
                            this.state.patient.map((data:any)=>{
                                return <li className="active" onClick={this.selectPatient} id={(counter++).toString()}><span>{data.PID.internalPatientId.value}</span><span>{data.PID.patientName.value.replace("^"," ")}</span></li>
                            })
                        }
                    </ul>
                </section>
            </div>
        )
    }
}

export default hot(Lab);