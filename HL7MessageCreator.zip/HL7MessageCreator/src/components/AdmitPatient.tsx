import * as React from 'react';
import { hot } from "react-hot-loader/root";
import TextField from '@material-ui/core/TextField';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import IconButton from '@material-ui/core/IconButton';
import SvgIcon from '@material-ui/core/SvgIcon';
import ContentEditable from 'react-contenteditable';
import Checkbox from '@material-ui/core/Checkbox';
 
const data = require("../data/admitPatient.json");
let DB = require("../DB.json");

const root = {
    margin: 10+"px",
    border:"1px solid gray"
};

interface Props {
    data:any
}
  
interface State {
    selectedOption: String;
    mshOption:String
    pv1Option:String
    pidOption:String
    message:any,
    count:Number,
    patient:any,
    index:number,
    allActive:boolean,
    isGenerated
}

class AdmitPatient extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props);
        this.state = { 
            selectedOption: "", 
            mshOption : "Select Other Feild",
            pv1Option : "Select Other Feild",
            pidOption : "Select Other Feild",
            message : [],
            patient : DB.patient.length ? DB.patient : [data],
            count : 1,
            index : 0,
            allActive:true,
            isGenerated : false
        };
        this.inputFields = this.inputFields.bind(this);
        this.segments = this.segments.bind(this);
        this.handleMSHChange = this.handleMSHChange.bind(this);
        this.handlePV1Change = this.handlePV1Change.bind(this);
        this.handlePIDChange = this.handlePIDChange.bind(this);
        this.onChangeHandler = this.onChangeHandler.bind(this);
        this.generateMessage = this.generateMessage.bind(this);
        this.onKeyPressHandler = this.onKeyPressHandler.bind(this);
        this.onChangeDateHandler = this.onChangeDateHandler.bind(this);
    }

    bindKeyDownHandler(){
        window.addEventListener("keydown",this.onKeyPressHandler);
    }
    unBindKeyDownHandler(){
        window.removeEventListener("keydown",this.onKeyPressHandler);
    }

    onKeyPressHandler = (event:any) =>{
        if(event.keyCode == 27){
            this.hideModel();
        }
    }

    onChangeHandler = (event:any) =>{
        event.stopPropagation();
        event.preventDefault();
        let mainKey = event.target.id.split(" ")[1];
        let subKey  = event.target.id.split(" ")[0];
        this.state.patient[mainKey][subKey].value = event.target.value;
        this.setState({patient:this.state.patient});
    }

    onChangeDateHandler = (event:any) =>{
        console.log(event.target.value);
    }

    inputFields = (data:any,segmentKey:any,mainKey:any) =>{
        if(!data.required)
        return "";
        segmentKey = segmentKey.trim();
        switch(segmentKey){
            case "no-segment" :
                return (
                    <TextField
                        id="datetime-local"
                        label="Date & Time"
                        type="datetime-local"
                        defaultValue="2020-01-01T10:00"
                        InputLabelProps={{
                            shrink: true,
                        }}
                        onChange={this.onChangeDateHandler}
                    />
                );
            default:
                return (
                    <TextField
                        required
                        id={segmentKey+" "+mainKey}
                        key={Math.random().toString().split(".")[1].substring(0,6)}
                        label={data.label}
                        value={data.value}
                        variant="outlined"
                        style={{margin:10+"px"}}
                        onChange={this.onChangeHandler}
                    />
                );
        }
    }

    handleMSHChange = (event:any) =>{
        this.state.patient[this.state.index].MSH[event.target.value].required = true;
        this.setState({patient:this.state.patient});
    }
    handlePV1Change = (event:any) =>{
        this.state.patient[this.state.index].PV1[event.target.value].required = true;
        this.setState({patient:this.state.patient});
    }
    handlePIDChange = (event:any) =>{
        this.state.patient[this.state.index].PID[event.target.value].required = true;
        this.setState({patient:this.state.patient});
    }

    segments = (segment:any,key:any) =>{

        if(key.toLowerCase() === "isremove")
            return ""

        let value:String = "Select Other Feild";
        let onChange;
        if(key === "MSH"){
            onChange = this.handleMSHChange;
        }else if(key === "PV1"){
            onChange = this.handlePV1Change;
        }else{
            onChange = this.handlePIDChange;
        }
        return (
            <form style={root} noValidate>
                <header style={{border:'1px solid gray',height:40+"px",background: "rgba(35, 104, 208, 0.09)"}}>
                    <span style={{ position: 'relative', top: '10px', left: '30px',fontWeight: 600}}>{key}</span>
                    <FormControl style={{minWidth: 120, position: 'relative', left: 36+"%"}}>
                        <Select
                            labelId={key+"demo-simple-select-label"}
                            id={key+"demo-simple-select"}
                            value={value}
                            onChange={onChange}
                        >
                        {
                             Object.keys(segment).map((segmentKey:any)=>{
                                var data = segment[segmentKey];
                                 return  <MenuItem style={data.required ? {'display':"none"} : {}} value={segmentKey}>{data.label}</MenuItem>
                             }) 
                        }
                        <MenuItem value="Select Other Feild">Select Other Field</MenuItem>
                        </Select>
                    </FormControl>
                </header>
                {
                   Object.keys(segment).map((segmentKey:any)=>{
                    var data = segment[segmentKey];
                     return this.inputFields(data,segmentKey,key);
                 }) 
                }
            </form>
        )
    }

    generateMessage = (event:any) =>{
    
        var message=[];
        var lastName = "";
        for(var i=1;i<= this.state.count; i++){
        
            var MSH = {};
            var msh = "MSH|";
            var mshData:any = {};
            Object.keys(data.MSH).map((key)=>{
                var dataObj = data.MSH[key];
                if(key != "fieldSeperator"){
                    msh += dataObj.value + (key != "principalLanguageOfMessage" ? "|" : "")
                }
                mshData[key] = dataObj;
            });

            MSH = mshData;

            var PID = {};
            var pid = "PID|";
            var pidData:any = {};
            Object.keys(data.PID).map((key)=>{
                var dataObj = data.PID[key];
                if(key === "patientAccountNumber"){
                    dataObj.value = data.PID["internalPatientId"].value;
                }
                if(key === "internalPatientId"){
                    dataObj.value = "V699508111" + Math.random().toString().split(".")[1].substring(0,7);
                }
                if(key === "patientName" && i > 1){
                   var firstName = dataObj.value.split("^")[1];
                   dataObj.value = lastName + (i - 1) + "^" + firstName;
                }else if(key === "patientName"){
                    lastName  = dataObj.value.split("^")[0];
                }
                pidData[key] = dataObj;
                pid += dataObj.value + (key != "patientDeathIndicator" ? "|" : "")
            });

            PID = pidData;

            var PV1 = {};
            var pv1 = "PV1|";
            var pv1Data:any = {};
            Object.keys(data.PV1).map((key)=>{
                var dataObj = data.PV1[key];
                pv1Data[key] = dataObj;
                pv1 += dataObj.value + (key != "otherHealthcareProvider" ? "|" : "")
            });
            PV1 = pv1Data;

            var obj = {msh,pv1,pid};
            DB.patient.push(JSON.parse(JSON.stringify({MSH,PID,PV1})));
            message.push(obj);
        }
        
        this.setState({message,patient:DB.patient,isGenerated:true});
    }

    showMessage = () =>{
        var message:any=[];

        this.state.patient.map((patient:any)=>{
            if(patient.isRemove)
                return;
            var MSH = {};
            var msh = "MSH|";
            var mshData:any = {};
            Object.keys(patient.MSH).map((key)=>{
                var data = patient.MSH[key];
                if(key != "fieldSeperator"){
                    msh += data.value + (key != "principalLanguageOfMessage" ? "|" : "")
                }
                mshData[key] = data;
            });

            MSH = mshData;

            var PID = {};
            var pid = "PID|";
            var pidData:any = {};
            Object.keys(patient.PID).map((key)=>{
                var data = patient.PID[key];
                pidData[key] = data;
                pid += data.value + (key != "patientDeathIndicator" ? "|" : "")
            });

            PID = pidData;

            var PV1 = {};
            var pv1 = "PV1|";
            var pv1Data:any = {};
            Object.keys(patient.PV1).map((key)=>{
                var data = patient.PV1[key];
                pv1Data[key] = data;
                pv1 += data.value + (key != "otherHealthcareProvider" ? "|" : "")
            });
            PV1 = pv1Data;

            var obj = {msh,pv1,pid};
            message.push(obj);
        });

        this.setState({message});

        this.showModel();
    }


    hideModel = () =>{
        let overlay:Element|null = document.querySelector(".overlay");
        if(overlay)
            overlay.classList.add("hide");
        
        let messageDisplay:Element|null = document.querySelector(".message-display");
        if(messageDisplay)
            messageDisplay.classList.add("hide");
        // this.setState({message:[]});

        this.unBindKeyDownHandler();
    }

    showModel = () =>{
        let overlay:Element|null = document.querySelector(".overlay");
        if(overlay)
            overlay.classList.remove("hide");
        
        let messageDisplay:Element|null = document.querySelector(".message-display");
        if(messageDisplay)
            messageDisplay.classList.remove("hide");

        this.bindKeyDownHandler();
    }

    onChangeCounter = (event:any) =>{
        this.setState({count:parseInt(event.target.value)});
    }

    handleMessageChange = () =>{
        
    }

    allMessages = () =>{
        var messages = "";
        this.state.message.map((obj:any)=>{
            messages += "<div class='message-seperator-wrapper'><div>" + obj.msh + "</div>" + "<div>"+obj.pid+"</div>" + "<div>"+obj.pv1+"</div><br></div>"
        })
        return messages;
    }

    resetAll = () =>{
        DB.patient = [];
        this.setState({patient:[],index:0});
    }

    deSelectAll = () =>{
        var allPatient = document.querySelectorAll("section.left > ul > li");
        allPatient.forEach((patient)=>{
            patient.classList.remove("active");
        });

        this.state.patient.map((patient:any)=>{
            patient.isRemove = true;
        });

        this.setState({patient : this.state.patient,allActive:false});
    }

    selectAll = () =>{
        var allPatient = document.querySelectorAll("section.left > ul > li");
        allPatient.forEach((patient)=>{
            patient.classList.add("active");
        });

        this.state.patient.map((patient:any)=>{
            patient.isRemove = false;
        });

        this.setState({patient : this.state.patient,allActive:true});
    }

    selectPatient = (event:any) =>{
        event.stopPropagation();
        event.preventDefault();
        var target = event.target;
        target = target.nodeName === "LI" ? target : target.closest("li");
        var index = parseInt(target.id);
        var patients = JSON.parse(JSON.stringify(this.state.patient));
        if(target.classList.contains('active')){
            target.classList.remove("active");
            var patient = patients[index];
            if(patient && !patient.isRemove){
                patient.isRemove = true;
                patients[index] = patient;
            }
        }else{
            target.classList.add("active");
            var patient = patients[index];
            patient.isRemove = false;
            patients[index] = patient;
        }

        this.setState({patient : patients,index});
    }

    messageGenerator = () =>{

        if(!DB.patient.length){
            return (<button onClick={this.generateMessage}>Generate</button>);
        }
        return (<button onClick={this.showMessage}>Show Messages</button>);
        
    }

    counterWrapper = () =>{
        if(!DB.patient.length){
            return (
                <div className="counter-wrapper">
                    <label>No of Message</label>
                    <input 
                        id="message_counter" 
                        defaultValue={this.state.count.toString()}
                        onChange={this.onChangeCounter}
                    />
                </div>
            );
        }
        return "";
    }

    changeHandler = (event:any)=>{

        var checked = event.target.checked;
        if(checked){
            this.selectAll();
            return;
        }
        this.deSelectAll();

    }

    patientList = (data:any,counter:number) =>{
        if(this.state.isGenerated)
            return (
                    <li className="active" onClick={this.selectPatient} id={(counter).toString()}>
                        <div>
                            <Checkbox
                                checked={!data.isRemove}
                                color="primary"
                                inputProps={{ 'aria-label': 'primary checkbox' }}
                            /> 
                        </div>
                        <div>
                            <span>{data.PID.internalPatientId.value}</span>
                            <span>{data.PID.patientName.value.replace("^"," ")}</span>
                        </div>
                    </li>
            );
        
        return "";
    }

    render():JSX.Element {
        var counter = 0;
        var buttonVisibility = this.state.patient.length > 0 ? 'block' : 'none';
        var emptyViewVisibility = buttonVisibility === "block" ? 'none' : 'block';
        var dataObj = this.state.patient.length ? this.state.patient[this.state.index] : data;
        return (
            <div className="admit-patient-wrapper1">
                <section className="left">
                    <div style={{'display':buttonVisibility}} className="main-checklist">
                        <Checkbox
                            checked={this.state.allActive}
                            color="primary"
                            onChange={this.changeHandler}
                            inputProps={{ 'aria-label': 'primary checkbox' }}
                        />
                        <span>Patients</span>
                        <button onClick={this.resetAll}>Reset</button>
                    </div>
                    <div style={{'display':emptyViewVisibility}}><span>No Patient Found</span></div>
                    <ul>
                        {
                            this.state.patient.map((data:any)=>{
                                return this.patientList(data,counter++)
                            })
                        }
                    </ul>
                </section>
                <section className="right">
                    {
                        Object.keys(dataObj).map((key:any)=>{
                            var segment = dataObj[key];
                            return this.segments(segment,key);
                        })
                    }
                    <footer style={{textAlign:"center"}}>
                        <div className="overlay hide" onClick={this.hideModel}></div>
                        {
                            this.messageGenerator()
                        }
                        <div className="message-display hide">
                            <IconButton aria-label="delete" style={{'position' : 'relative', float: 'right',bottom: '20px',left: '20px'}} onClick={this.hideModel}>
                            <SvgIcon>
                                <path d="M14.59 8L12 10.59 9.41 8 8 9.41 10.59 12 8 14.59 9.41 16 12 13.41 14.59 16 16 14.59 13.41 12 16 9.41 14.59 8zM12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" />
                            </SvgIcon>
                            </IconButton>
                            <div className="message-wrapper">
                                <ContentEditable
                                    html={this.allMessages()} // innerHTML of the editable div
                                    style={{borderBottom:'10px',padding:'5px',borderRadius:'5px',border:'1px ridge #80808029'}}
                                    disabled={false}       // use true to disable editing
                                    onChange={this.handleMessageChange} // handle innerHTML change
                                    tagName='p'
                                />
                            </div>
                        </div>
                        {
                            this.counterWrapper()
                        }
                    </footer>
                </section>
            </div>
        )
    }
}

export default hot(AdmitPatient);