import * as React from 'react';
import { hot } from "react-hot-loader/root";
import TextField from '@material-ui/core/TextField';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import IconButton from '@material-ui/core/IconButton';
import SvgIcon from '@material-ui/core/SvgIcon';
import ContentEditable from 'react-contenteditable';
import Checkbox from '@material-ui/core/Checkbox';
 
let DB = require("../DB.json");

interface Props {
}
  
interface State {
    message:any,
    patient:any,
    index:number,
    allActive:boolean
}

class CancelAdmit extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props);
        this.state = { 
            message : [],
            patient : JSON.parse(JSON.stringify(DB.patient)),
            index : 0,
            allActive:true
        };
        this.inputFields = this.inputFields.bind(this);
        this.onKeyPressHandler = this.onKeyPressHandler.bind(this);
    }

    changeHandler = (event:any)=>{

        var checked = event.target.checked;
        if(checked){
            this.selectAll();
            return;
        }
        this.deSelectAll();

    }

    bindKeyDownHandler(){
        window.addEventListener("keydown",this.onKeyPressHandler);
    }
    unBindKeyDownHandler(){
        window.removeEventListener("keydown",this.onKeyPressHandler);
    }

    onKeyPressHandler = (event:any) =>{
        if(event.keyCode == 27){
            this.hideModel();
        }
    }

    onChangeHandler = (event:any) =>{
        event.stopPropagation();
        event.preventDefault();
        let mainKey = event.target.id.split(" ")[1];
        let subKey  = event.target.id.split(" ")[0];
        this.state.patient[this.state.index][mainKey][subKey].value = event.target.value;
        this.setState({patient:this.state.patient});
    }

    inputFields = (data:any,segmentKey:any,mainKey:any) =>{
        if(!data.required)
        return "";
        segmentKey = segmentKey.trim();
        switch(segmentKey){
            case "no-segment" :
                return (
                    <TextField
                        id="datetime-local"
                        label="Date & Time"
                        type="datetime-local"
                        defaultValue="2020-01-01T10:00"
                        InputLabelProps={{
                            shrink: true,
                        }}
                    />
                );
            default:
                return (
                    <TextField
                        required
                        id={segmentKey+" "+mainKey}
                        label={data.label}
                        value={data.value}
                        variant="outlined"
                        style={{margin:10+"px"}}
                        onChange={this.onChangeHandler}
                    />
                );
        }
    }

    getMonthDay = (month:string,year:string)=>{
        if(month == "01" || month == "03" || month == "05" || month == "07" || month == "08" || month == "10" || month == "12"){
            return 31;
        }else if(month == "02"){
            if(parseInt(year) % 4 === 0){
                return 29;
            }else{
                return 28;
            }
        }
        return 30;
    }

    generateMessage = (event:any) =>{
        
        var message:any=[];

        this.state.patient.map((patient:any)=>{
            if(patient.isRemove)
                return;
            var MSH = {};
            var msh = "MSH|";
            var mshData:any = {};
            Object.keys(patient.MSH).map((key)=>{
                var data = patient.MSH[key];

                if(key === "dateAndTime"){
                    data.value = patient.MSH[key].value;
                    var year = data.value.substring(0,4);
                    var month = data.value.substring(4,6);
                    var day = data.value.substring(6,8);
                    var hour = data.value.substring(8,10);
                    var min = data.value.substring(10,12);
                    var sec = data.value.substring(12,14);
                    var monthEnd = this.getMonthDay(month,year);
                    hour =  parseInt(hour);
                    month = parseInt(month);
                    year = parseInt(year);
                    hour++;
                    if(hour > 23){
                        hour = "00";
                        day++;
                        if(day > monthEnd){
                            day = "01";
                            month++;
                            if(month > 12){
                                month = "01";
                                year++;
                            }
                        }
                    }
                    data.value = year.toString() + month.toString() + day.toString() + hour.toString() + min + sec;
                }

                if(key === "messageType"){
                    data.value = "ADT^A11"
                }

                if(key != "fieldSeperator"){
                    msh += data.value + (key != "principalLanguageOfMessage" ? "|" : "")
                }
                mshData[key] = data;
            });

            MSH = mshData;

            var PID = {};
            var pid = "PID|";
            var pidData:any = {};
            Object.keys(patient.PID).map((key)=>{
                var data = patient.PID[key];
                pidData[key] = data;
                pid += data.value + (key != "patientDeathIndicator" ? "|" : "")
            });

            PID = pidData;

            var PV1 = {};
            var pv1 = "PV1|";
            var pv1Data:any = {};
            Object.keys(patient.PV1).map((key)=>{
                var data = patient.PV1[key];
                pv1Data[key] = data;
                pv1 += data.value + (key != "otherHealthcareProvider" ? "|" : "")
            });
            PV1 = pv1Data;

            var obj = {msh,pv1,pid};
            message.push(obj);
        });

        this.setState({message});

        event.target.nextElementSibling.classList.remove("hide");
        event.target.previousElementSibling.classList.remove("hide");

        this.bindKeyDownHandler();
    }


    hideModel = () =>{
        let overlay:Element|null = document.querySelector(".overlay");
        if(overlay)
            overlay.classList.add("hide");
        
        let messageDisplay:Element|null = document.querySelector(".message-display");
        if(messageDisplay)
            messageDisplay.classList.add("hide");
        this.setState({message:[]});

        this.unBindKeyDownHandler();
    }

    allMessages = () =>{
        var messages = "";
        this.state.message.map((obj:any)=>{
            messages += "<div class='message-seperator-wrapper'><div>" + obj.msh + "</div>" + "<div>"+obj.pid+"</div>" + "<div>"+obj.pv1+"</div><br></div>"
        })
        return messages;
    }

    deSelectAll = () =>{
        var allPatient = document.querySelectorAll("section.left > ul > li");
        allPatient.forEach((patient)=>{
            patient.classList.remove("active");
        });

        this.state.patient.map((patient:any)=>{
            patient.isRemove = true;
        });

        this.setState({patient : this.state.patient,allActive:false});
    }

    selectAll = () =>{
        var allPatient = document.querySelectorAll("section.left > ul > li");
        allPatient.forEach((patient)=>{
            patient.classList.add("active");
        });

        this.state.patient.map((patient:any)=>{
            patient.isRemove = false;
        });

        this.setState({patient : this.state.patient,allActive:true});
    }

    selectPatient = (event:any) =>{
        event.stopPropagation();
        event.preventDefault();
        var target = event.target;
        target = target.nodeName === "LI" ? target : target.closest("li");
        var index = parseInt(target.id);
        var patients = JSON.parse(JSON.stringify(this.state.patient));
        if(target.classList.contains('active')){
            target.classList.remove("active");
            var patient = patients[index];
            if(patient && !patient.isRemove){
                patient.isRemove = true;
                patients[index] = patient;
            }
        }else{
            target.classList.add("active");
            var patient = patients[index];
            patient.isRemove = false;
            patients[index] = patient;
        }

        this.setState({patient : patients,index});
    }

    handleMessageChange = () =>{
        
    }

    render():JSX.Element {
        var counter = 0;
        var buttonVisibility = this.state.patient.length > 0 ? 'inline-block' : 'none';
        var emptyViewVisibility = buttonVisibility === "inline-block" ? 'none' : 'bock';
        return (
            <div className="admit-patient-wrapper1">
                <section className="left">
                <div style={{'display':buttonVisibility}}>
                        <Checkbox
                            checked={this.state.allActive}
                            color="primary"
                            onChange={this.changeHandler}
                            inputProps={{ 'aria-label': 'primary checkbox' }}
                        />
                        <span>Patients</span>
                    </div>
                    <div style={{'display':emptyViewVisibility}}>
                        <span>No Patient Found</span>
                        <a href="/admitPatient">Admit Patient</a>
                    </div>
                    <ul>
                        {
                            this.state.patient.map((data:any)=>{
                                return <li key={counter} className="active" onClick={this.selectPatient} id={(counter++).toString()}>
                                    <div>
                                        <Checkbox
                                            checked={!data.isRemove}
                                            color="primary"
                                            inputProps={{ 'aria-label': 'primary checkbox' }}
                                        /> 
                                    </div>
                                    <div>
                                        <span>{data.PID.internalPatientId.value}</span>
                                        <span>{data.PID.patientName.value.replace("^"," ")}</span>
                                    </div>
                                </li>
                            })
                        }
                    </ul>
                </section>
                <section className="right">
                    <footer style={{textAlign:"center"}}>
                        <div className="overlay hide" onClick={this.hideModel}></div>
                        <button style={{marginTop : '25%',border:"1px solid gray",borderRadius:'5px'}} onClick={this.generateMessage}>Generate</button>
                        <div className="message-display hide">
                            <IconButton aria-label="delete" style={{'position' : 'relative', float: 'right',bottom: '20px',left: '20px'}} onClick={this.hideModel}>
                            <SvgIcon>
                                <path d="M14.59 8L12 10.59 9.41 8 8 9.41 10.59 12 8 14.59 9.41 16 12 13.41 14.59 16 16 14.59 13.41 12 16 9.41 14.59 8zM12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" />
                            </SvgIcon>
                            </IconButton>
                            <div className="message-wrapper">
                                <ContentEditable
                                    html={this.allMessages()} // innerHTML of the editable div
                                    style={{borderBottom:'10px',padding:'5px',borderRadius:'5px',border:'1px ridge #80808029'}}
                                    disabled={false}       // use true to disable editing
                                    onChange={this.handleMessageChange} // handle innerHTML change
                                    tagName='p'
                                />
                            </div>
                        </div>
                    </footer>
                </section>
            </div>
        )
    }
}

export default hot(CancelAdmit);