import React,{Component} from 'react';
import CreateInvoice from './createInvoice';

export default class InvoiceComp extends Component{
    constructor(props){
        super(props);
        this.state = {createInvoiceComp : "",'displayInvoiceList':{'display':'block'}};
    }

    invoice = (props) => {
        return (
          <li>
            <div className="sme-product-comp-list-item">
              <header>{props.invoice.date}</header>
              <div>
                <div>
                  <span>{props.invoice.invoiceTo}</span>
                  <span>{props.invoice.products}</span>
                </div>
              </div>
            </div>
          </li>
        );
    };

    createNewInvoice = () =>{
        this.setState({'createInvoiceComp' : <CreateInvoice saveInvoice={this.props.createInvData}/>,'displayInvoiceList':{'display':'none'}})
    }

    clearView = () =>{
        // this.setState({'createInvoiceComp' : "",'displayInvoiceList':{'display':'block'}});
        this.state.createInvoiceComp = "";
        this.state.displayInvoiceList = {'display':'block'};
    }

    render(){
        return(
            <div className="mse-invoice-comp-wrapper">
                <header>
                    <button onClick={this.createNewInvoice.bind(this)}>Create New Invoice</button>
                </header>
                <div style={this.state.displayInvoiceList}>
                    <ul>
                        {
                            this.props.dataList.map((invoice)=>{
                                return <this.invoice invoice={invoice} />
                            })
                        }
                    </ul>
                </div>
                {
                    this.state.createInvoiceComp
                }
            </div>
        );
    }
}