import React,{Component} from 'react';
export default class CreateInvoice extends Component{
    constructor(props){
        super(props);
    }

    saveInvoice = () =>{
        var invoice = {
            "date"      : document.querySelector("#invoice_date").value,
            "invoiceTo" : document.querySelector("#invoice_to").value,
            "products"  : document.querySelector("#invoice_products").value
        };
        this.props.saveInvoice(invoice);
    };
        
    resetInvoice = () =>{
        document.querySelector("#invoice_date").value = "";
        document.querySelector("#invoice_to").value = "";
        document.querySelector("#invoice_products").value = "";
    };

    render(){
        return (
            <div className="create-invoice-field-set">
              <input type="text" id="invoice_date" placeholder="Date"/>
              <input type="text" id="invoice_to" placeholder="Invoice To" />
              <input type="text" id="invoice_products" placeholder="Products" />
              <button onClick={this.saveInvoice.bind(this)}>Save</button><button onClick={this.resetInvoice.bind(this)}>Reset</button>
            </div>
          );
    }
}
  