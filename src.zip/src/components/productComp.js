import React,{Component} from 'react';

class ProductComp extends Component{
    constructor(props){
        super(props);
    }

    product = (props) => {
        return (
          <li>
            <div className="sme-product-comp-list-item">
              <header>{props.product.title}</header>
              <div>{props.product.description}</div>
            </div>
          </li>
        );
    }

    render(){
        return(
            <div className="mse-product-comp-wrapper">
                <header>
                    <button>Create New Product</button>
                </header>
                <div>
                    <ul>
                        {
                            this.props.dataList.map((product)=>{
                                return <this.product product={product} />
                            })
                        }
                    </ul>
                </div>
            </div>
        );
    }
}

export default ProductComp;