import React from 'react';
import logo from './logo.svg';
import './App.css';

function App(props) {
  return (
    <div className="App">
      <span>{props.name}</span>
      <span>{props.age}</span>
    </div>
  );
}

export default App;