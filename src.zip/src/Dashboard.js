import React,{Component} from 'react';
import App from './App';
export default class Dashboard extends Component{
    constructor(props){
        super(props);
        this.state = this.props.data;
    }

    changeAge = () =>{
        this.state.age++;
        this.setState(this.state);
    }

    render(){
        return(
            <div className="dashboard">
                <App name={this.state.name} age={this.state.age}/>
                <button onClick={this.changeAge.bind(this)}>Change Age</button>
            </div>
        );
    }
}