import React,{Component} from 'react';
import SMEHeadder from './layout';
import InvoiceComp from './components/invoiceComp';
import ProductComp from './components/productComp';
export default class Dashboard extends Component{
    constructor(props){
        super(props);
        this.data = {
            "product" : [
                    {
                        "title" : "product-1",
                        "description" : "product-1 description"
                    },
                    {
                        "title" : "product-2",
                        "description" : "product-2 description"
                    },
                    {
                        "title" : "product-3",
                        "description" : "product-3 description"
                    }
                ],
            "invoice" : [
                    {
                        "date" : "16/10/2019",
                        "invoiceTo" : "client-1",
                        "products"  : "product-1,product-2"
                    },
                    {
                        "date" : "15/10/2019",
                        "invoiceTo" : "client-2",
                        "products"  : "product-1,product-3"
                    },
                    {
                        "date" : "14/10/2019",
                        "invoiceTo" : "client-3",
                        "products"  : "product-2,product-3"
                    }
                ]
        };
        this.state = {
            userInfo : this.props.data,
            data : this.data.product,
            view : "product"
        }
    }

    selectMenuItem = (event) =>{
        var target = event.target.nodeName != "LI" ? event.target.parentElement : event.target;
        switch(target.id){
            case "product" :
                this.setState({'view':"product",'data':this.data.product});
                break;
            case "invoice" :
                this.setState({'view':"invoice",'data':this.data.invoice});
                break;
        }
    }

    printComponent= (view) =>{
        switch(view){
            case "product" : 
                return <ProductComp dataList={this.state.data} />
            case "invoice" :
                return <InvoiceComp dataList={this.state.data} />
        }
    }

    render(){
        return(
            <div className="dashboard">
                <SMEHeadder userInfo={this.state.userInfo}/>
                <section className="sme-left-section">
                    <ul className="sme-left-section-list">
                        <li id="product" onClick={this.selectMenuItem.bind(this)}><a href="#">Products</a></li>
                        <li id="invoice" onClick={this.selectMenuItem.bind(this)}><a href="#">Invoices</a></li>
                    </ul>
                </section>
                <section className="sme-right-section">
                    {
                        this.printComponent(this.state.view)
                    }
                </section>
            </div>
        );
    }
}