import React,{Component} from 'react';

export default class InvoiceComp extends Component{
    constructor(props){
        super(props);
    }

    invoice = (props) => {
        return (
          <li>
            <div className="sme-product-comp-list-item">
              <header>{props.invoice.date}</header>
              <main>
                <div>
                  <span>{props.invoice.invoiceTo}</span>
                  <span>{props.invoice.products}</span>
                </div>
              </main>
            </div>
          </li>
        );
    }

    render(){
        return(
            <div className="mse-invoice-comp-wrapper">
                <header>
                    <button>Create New Invoice</button>
                </header>
                <main>
                    <ul>
                        {
                            this.props.dataList.map((invoice)=>{
                                return <this.invoice invoice={invoice} />
                            })
                        }
                    </ul>
                </main>
            </div>
        );
    }
}