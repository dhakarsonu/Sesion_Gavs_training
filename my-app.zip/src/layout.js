import React from 'react';
import './App.css';

export default function SMEHeadder(props) {
  return (
    <header className="sme-header">
        <div><span>{props.userInfo.name}</span></div>
    </header>
  );
}

export function product(props) {
  return (
    <li>
      <div className="sme-product-comp-list-item">
        <header>{props.product.title}</header>
        <main>{props.product.description}</main>
      </div>
    </li>
  );
}

export function invoice(props) {
  return (
    <li>
      <div className="sme-product-comp-list-item">
        <header>{props.invoice.date}</header>
        <main>
          <div>
            <span>{props.invoice.invoiceTo}</span>
            <span>{props.invoice.products}</span>
          </div>
        </main>
      </div>
    </li>
  );
}