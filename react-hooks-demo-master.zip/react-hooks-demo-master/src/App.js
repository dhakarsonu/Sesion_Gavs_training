import React, { Component } from 'react'
import './App.css'
import Counter from './examples/useState/Counter'

class App extends Component {
  render () {
    return (
      <Counter />
    )
  }
}

export default App
